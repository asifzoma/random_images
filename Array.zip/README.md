# random_images
Random image generator which allows you to save images to an email address
